package com.louis.kitty.admin.sevice;

import com.louis.kitty.admin.model.SysLog;
import com.louis.kitty.core.service.CurdService;

/**
 * 日志管理
 * @author Louis
 * @date Oct 29, 2018
 */
public interface SysLogService extends CurdService<SysLog> {

}
